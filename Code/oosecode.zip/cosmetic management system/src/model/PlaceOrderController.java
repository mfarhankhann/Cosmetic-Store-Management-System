/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author LENOVO
 */
public class PlaceOrderController {

    private int orderID;
    private String CName;
    private String CAddress;
    private int quantity;
    private double totalPrice;
    private double shipFee;
}
