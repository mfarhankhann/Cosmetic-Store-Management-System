/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cms.bl.validators;

import cms.bl.common.CustomerDTO;
import cms.bl.common.Response;

/**
 *
 * @author Talah Khan
 */
public class customerValidators {
     public Response isValidCustomerDTO(CustomerDTO customerDTO) {
        Response objRespone = new Response();
        if(!isValidusername(customerDTO.username))
        {
            objRespone.AddErrorMessage("Invalid Title found. The length of title should be more than 3 and less than 50.");
        }
        //TODO: Perform remaining validations
        
        return objRespone;
    }

    private boolean isValidusername(String title) {
        if(title == null || title.length() < 3 || title.length() > 50 || title.equals(""))
            return false;
        return true;
    }
}
