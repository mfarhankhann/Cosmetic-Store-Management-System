/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cms.b.l;

/**
 *
 * @author Talah Khan
 */
public class cmsController {
    MarksManager objMarksManager = new MarksManager();
    public Response saveMarks(MarksDTO marksDTO) {
        return objMarksManager.saveMarks(marksDTO);
    }
    
}
