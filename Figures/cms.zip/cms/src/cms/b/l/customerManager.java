/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cms.b.l;

import cms.bl.common.Response;

/**
 *
 * @author Talah Khan
 */
public class customerManager {
        private DAL objDal;
    
    public customerManager(){
        objDal = new DAL();
    }
    
    public Response saveCustomer(CustomerDTO customerDTO) {
        customerValidators objcustomerValidators = new customerValidators();
        Response obResponse = objcustomerValidators.isValidMarksDTO(customerDTO);
        if(obResponse.IsSuccessful())
        {
            obResponse = objDal.savecustomerInDB(customerDTO);
        }
        return obResponse;
    }
}
